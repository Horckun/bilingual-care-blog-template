# Private migration guide

Keep the WordPress export, its media and all real redirects in the private production repository. This public template must never contain them.

1. Export WordPress XML manually from the site administration area; this tool never connects to WordPress.
2. Create an isolated private production checkout and run a dry inventory:

   `node --experimental-strip-types scripts/import-wordpress.mts --input /private/export.xml --output /private/migration --dry-run`

3. Review titles, slugs, dates, authors, media rights and bilingual pairs before producing MDX drafts.
4. Build a legacy path inventory, add reviewed redirects in the private repository, then validate it:

   `node --experimental-strip-types scripts/validate-redirects.mts inventory.txt redirects.json`

5. Test the full redirect map on a preview deployment before changing DNS or touching the existing WordPress site.

The importer writes only to the explicitly supplied output directory. Do not point it at this public template.
