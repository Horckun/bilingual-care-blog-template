# Editing content

Create paired MDX articles under `src/content/articles/fr` and `src/content/articles/es`. Use the same `translationId` when a translation exists, keep each locale's slug and metadata independent, and provide meaningful alt text for every cover. Drafts stay out of public archives.

Run `npm run validate:content` before review. Use only neutral demonstration material in the public template; create and edit real content in the private production repository.
