# Deployment

Deploy the static build to Cloudflare Pages or another static host. Cloudflare Pages uses build command `npm run build` and output directory `dist`. Preview deployments must use `PUBLIC_DEPLOYMENT_MODE=preview` and have no `PUBLIC_SITE_URL`; this emits noindex metadata. Production configuration belongs only in the private repository, with `PUBLIC_DEPLOYMENT_MODE=production` and the verified canonical URL.

Before connecting a repository, ensure the lockfile is committed and CI passes `npm ci`, checks, tests, boundary scan, build and link audit. Create a provider preview URL first; do not use the existing production domain during this stage.

Do not point an existing domain or change DNS until the private migration inventory, redirects, build and responsive checks have passed.

For the private analytics Worker, the checked-in `ACCESS_JWT_VERIFIER` service name is a template placeholder. It is valid only for template and preview checks. Before a production deployment, replace it in the private Worker configuration with the private Access/JWKS verifier service and run `ANALYTICS_DEPLOYMENT_MODE=production npm run check:analytics-access`. The command fails if the placeholder is still present; no verifier value belongs in the public template.

Keep `CLOUDFLARE_ANALYTICS_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, Access issuer/audience and owner allowlist only in the protected Worker environment. Apply the D1 migration before enabling the Worker cron triggers. Review `docs/ANALYTICS.md` for the aggregate-only privacy rules, scheduled report periods and the required private post-deployment GraphQL capability check.
