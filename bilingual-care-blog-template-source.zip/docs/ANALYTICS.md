# Private analytics operations

The public website contains no private analytics results, account identifiers or server credentials. Local and preview builds keep the analytics beacon disabled. The `/admin/estadisticas/` area is a protected server-rendered dashboard and is not a public reporting page.

## What is collected

Only aggregate visits, page views, country and referrer summaries supplied by the provider are stored in private reports. The system must not store raw IP addresses, visitor identifiers, request headers, form values or email addresses from visitors.

Provider sampling or unavailable dimensions are shown as such in the dashboard and reports. They are never represented as exact values.

## Private production setup

Perform these steps only in the private production repository and Cloudflare account:

1. Enable Cloudflare Web Analytics only after the privacy notice has been reviewed.
2. Create a narrowly scoped Analytics API token and place it in the Worker secret store as `CLOUDFLARE_ANALYTICS_API_TOKEN`.
3. Set the account identifier only in the Worker environment as `CLOUDFLARE_ACCOUNT_ID`.
4. Create the D1 database and apply `analytics-worker/migrations/0001_analytics.sql`.
5. Configure Cloudflare Access for the owner and set the server-only issuer, audience and owner allowlist values.
6. Replace the private `ACCESS_JWT_VERIFIER` service placeholder in the private Worker configuration. Run `ANALYTICS_DEPLOYMENT_MODE=production npm run check:analytics-access`; it must pass before deployment.

Never commit any of those values, export a report into public assets or enable the production beacon in preview.

## Scheduled reports

The Worker schedules weekly reports at `08:00 UTC` every Monday and monthly reports at `08:00 UTC` on day 1. Each report covers the preceding complete UTC period. Re-running a job is idempotent; the same report period is not duplicated.

No email delivery is part of this template. Reports are retained privately for authenticated dashboard viewing and download.

## Post-deployment capability check

Before relying on a provider dimension, run a private GraphQL capability query with the scoped token and record which fields are available for the account. Keep this record outside the public template. Unsupported dimensions must remain marked as unavailable rather than causing report generation to fail.
