import { getPreviousMonthlyPeriod, getPreviousWeeklyPeriod } from '../../src/analytics/periods.ts';
import { createCloudflareAnalyticsProvider, type ServerAnalyticsEnvironment } from '../../src/analytics/provider.ts';
import { D1ReportRepository, type D1DatabaseLike, type ReportRepository } from '../../src/analytics/repository.ts';
import { generateReport } from '../../src/analytics/reports.ts';
import type { AnalyticsProvider } from '../../src/analytics/provider.ts';
import { demoAnalyticsAggregate } from '../../src/analytics/fixtures.ts';
import { createEnvironmentAccessVerifier, requireAnalyticsOwner, type AccessEnvironment, type AccessVerifier } from './auth.ts';

export const WEEKLY_CRON = '0 8 * * MON';
export const MONTHLY_CRON = '0 8 1 * *';

export interface AnalyticsWorkerEnvironment extends ServerAnalyticsEnvironment, AccessEnvironment { ANALYTICS_DB: D1DatabaseLike; }
type ScheduledController = { cron: string; scheduledTime?: number };
type ExecutionContext = { waitUntil(promise: Promise<unknown>): void };

export interface ScheduledReportDependencies { provider?: AnalyticsProvider; repository?: ReportRepository; }
export interface WorkerDependencies { verifier?: AccessVerifier; provider?: AnalyticsProvider; repository?: (env: AnalyticsWorkerEnvironment) => ReportRepository; }

export async function runScheduledReport(cron: string, env: AnalyticsWorkerEnvironment, now = new Date(), dependencies: ScheduledReportDependencies = {}): Promise<void> {
  const period = cron === WEEKLY_CRON ? getPreviousWeeklyPeriod(now) : cron === MONTHLY_CRON ? getPreviousMonthlyPeriod(now) : undefined;
  if (!period) return;
  await generateReport(period, dependencies.provider ?? createCloudflareAnalyticsProvider(env), dependencies.repository ?? new D1ReportRepository(env.ANALYTICS_DB), cron, () => now);
}

function reportPeriodFromId(id: string) {
  const match = id.match(/^report-(weekly|monthly)-(\d{4}-\d{2}-\d{2})-(\d{4}-\d{2}-\d{2})-v1$/);
  return match ? { type: match[1] as 'weekly' | 'monthly', start: match[2], end: match[3] } : undefined;
}

export function createAnalyticsWorker(dependencies: WorkerDependencies = {}) {
  const repositoryFor = (env: AnalyticsWorkerEnvironment) => dependencies.repository?.(env) ?? new D1ReportRepository(env.ANALYTICS_DB);
  const providerFor = (env: AnalyticsWorkerEnvironment) => dependencies.provider ?? createCloudflareAnalyticsProvider(env);
  return {
  async fetch(request: Request, env: AnalyticsWorkerEnvironment): Promise<Response> {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/admin/estadisticas/api/')) return new Response('Not found', { status: 404 });
    try { await requireAnalyticsOwner(request, env, dependencies.verifier ?? createEnvironmentAccessVerifier(env)); } catch (error) { return error instanceof Response ? error : new Response('Unauthorized', { status: 401 }); }
    if (url.pathname === '/admin/estadisticas/api/summary') {
      if (env.ANALYTICS_DEMO_MODE === 'true') return Response.json({ aggregate: demoAnalyticsAggregate, mode: 'demo' }, { headers: { 'Cache-Control': 'no-store' } });
      const repository = repositoryFor(env);
      const period = getPreviousWeeklyPeriod(new Date());
      const report = await repository.findByPeriod(period);
      const aggregate = report?.aggregate ?? await providerFor(env).query(period);
      return Response.json({ aggregate, mode: 'production' }, { headers: { 'Cache-Control': 'no-store' } });
    }
    const reportMatch = url.pathname.match(/^\/admin\/estadisticas\/api\/reports\/([a-z0-9-]+)$/i);
    if (!reportMatch) return new Response('Not found', { status: 404 });
    const reportId = reportMatch[1];
    const period = reportPeriodFromId(reportId);
    if (!period) return new Response('Not found', { status: 404 });
    const report = env.ANALYTICS_DEMO_MODE === 'true' ? { id: reportId, aggregate: demoAnalyticsAggregate } : await repositoryFor(env).findByPeriod(period);
    if (!report) return new Response('Not found', { status: 404 });
    return new Response(JSON.stringify(report, null, 2), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="${reportId}.json"`, 'Cache-Control': 'no-store' } });
  },
  async scheduled(controller: ScheduledController, env: AnalyticsWorkerEnvironment, ctx: ExecutionContext) {
    const now = new Date(controller.scheduledTime ?? Date.now());
    ctx.waitUntil(runScheduledReport(controller.cron, env, now));
  },
  };
}

export default createAnalyticsWorker();
