export interface OwnerIdentity { email: string; subject: string; }

export interface AccessEnvironment {
  ANALYTICS_DEMO_MODE?: string;
  ANALYTICS_OWNER_EMAIL?: string;
  ACCESS_ISSUER?: string;
  ACCESS_AUDIENCE?: string;
  /** Server-side binding supplied at deployment; never exposed to the browser. */
  ACCESS_JWT_VERIFIER?: AccessVerifierBinding | AccessVerifierServiceBinding;
}

export type AccessVerifier = (token: string, environment: Required<Pick<AccessEnvironment, 'ACCESS_ISSUER' | 'ACCESS_AUDIENCE'>>) => Promise<OwnerIdentity | undefined>;
export interface AccessVerifierBinding {
  verify(token: string, environment: Required<Pick<AccessEnvironment, 'ACCESS_ISSUER' | 'ACCESS_AUDIENCE'>>): Promise<OwnerIdentity | undefined>;
}
export interface AccessVerifierServiceBinding {
  fetch(request: Request): Promise<Response>;
}

/**
 * Resolves the verifier from the Worker environment rather than relying on
 * application-code injection. Deployments bind this to a server-side JWKS/JWT
 * verifier; missing configuration intentionally fails closed.
 */
export function createEnvironmentAccessVerifier(environment: AccessEnvironment): AccessVerifier | undefined {
  const binding = environment.ACCESS_JWT_VERIFIER;
  if (!binding) return undefined;
  if ('verify' in binding) return (token, config) => binding.verify(token, config);
  if ('fetch' in binding) return async (token, config) => {
    const response = await (binding as unknown as AccessVerifierServiceBinding).fetch(new Request('https://access-verifier.internal/verify', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ token, issuer: config.ACCESS_ISSUER, audience: config.ACCESS_AUDIENCE }),
    }));
    if (!response.ok) return undefined;
    const identity = await response.json() as Partial<OwnerIdentity>;
    return typeof identity.email === 'string' && typeof identity.subject === 'string' ? { email: identity.email, subject: identity.subject } : undefined;
  };
  return undefined;
}

/** Fails closed until the deployment supplies a signature-validating Access verifier. */
/**
 * The verifier is deliberately injected by the Worker entrypoint. Production
 * deployments wire a JWT/JWKS verifier here; no browser bundle ever receives
 * the issuer, audience or owner allowlist.
 */
export async function requireAnalyticsOwner(request: Request, environment: AccessEnvironment, verifier = createEnvironmentAccessVerifier(environment)): Promise<OwnerIdentity> {
  if (environment.ANALYTICS_DEMO_MODE === 'true') return { email: 'demo-owner@example.invalid', subject: 'demo-owner' };
  const token = request.headers.get('Cf-Access-Jwt-Assertion');
  if (!token || !verifier || !environment.ANALYTICS_OWNER_EMAIL || !environment.ACCESS_ISSUER || !environment.ACCESS_AUDIENCE) throw new Response('Unauthorized', { status: 401 });
  const identity = await verifier(token, { ACCESS_ISSUER: environment.ACCESS_ISSUER, ACCESS_AUDIENCE: environment.ACCESS_AUDIENCE });
  if (!identity || identity.email !== environment.ANALYTICS_OWNER_EMAIL) throw new Response('Forbidden', { status: 403 });
  return identity;
}
