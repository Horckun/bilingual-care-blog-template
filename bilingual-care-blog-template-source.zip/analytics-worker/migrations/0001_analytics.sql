CREATE TABLE IF NOT EXISTS analytics_reports (
  id TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('weekly', 'monthly')),
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  schema_version INTEGER NOT NULL DEFAULT 1,
  aggregate_json TEXT NOT NULL,
  generated_at TEXT NOT NULL,
  summary TEXT NOT NULL,
  PRIMARY KEY (type, start_date, end_date, schema_version)
);

CREATE TABLE IF NOT EXISTS analytics_job_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  period_type TEXT NOT NULL,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  cron TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('generated', 'reused', 'failed')),
  occurred_at TEXT NOT NULL
);
