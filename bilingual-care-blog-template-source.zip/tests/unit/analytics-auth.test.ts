import { describe, expect, it } from 'vitest';
import { createEnvironmentAccessVerifier, requireAnalyticsOwner } from '../../analytics-worker/src/auth.ts';

describe('analytics owner guard', () => {
  const request = new Request('https://example.invalid/admin/estadisticas/api/summary', {
    headers: { 'Cf-Access-Jwt-Assertion': 'signed-token' },
  });
  const env = { ANALYTICS_OWNER_EMAIL: 'owner@example.invalid', ACCESS_ISSUER: 'https://access.example.invalid', ACCESS_AUDIENCE: 'audience' };

  it('accepts only an injected verifier identity matching the server allowlist', async () => {
    await expect(requireAnalyticsOwner(request, env, async () => ({ email: 'owner@example.invalid', subject: 'owner' }))).resolves.toEqual({ email: 'owner@example.invalid', subject: 'owner' });
    await expect(requireAnalyticsOwner(request, env, async () => ({ email: 'other@example.invalid', subject: 'other' }))).rejects.toMatchObject({ status: 403 });
  });

  it('fails closed if verification configuration is missing', async () => {
    await expect(requireAnalyticsOwner(request, { ANALYTICS_OWNER_EMAIL: 'owner@example.invalid' }, async () => ({ email: 'owner@example.invalid', subject: 'owner' }))).rejects.toMatchObject({ status: 401 });
  });

  it('uses the server-side verifier binding by default', async () => {
    const configured = {
      ...env,
      ACCESS_JWT_VERIFIER: { verify: async () => ({ email: 'owner@example.invalid', subject: 'owner' }) },
    };
    expect(createEnvironmentAccessVerifier(configured)).toBeTypeOf('function');
    await expect(requireAnalyticsOwner(request, configured)).resolves.toEqual({ email: 'owner@example.invalid', subject: 'owner' });
  });

  it('adapts a private verifier service binding', async () => {
    const configured = { ...env, ACCESS_JWT_VERIFIER: { fetch: async () => Response.json({ email: 'owner@example.invalid', subject: 'service-owner' }) } };
    await expect(requireAnalyticsOwner(request, configured)).resolves.toEqual({ email: 'owner@example.invalid', subject: 'service-owner' });
  });
});
