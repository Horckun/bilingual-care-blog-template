import { existsSync } from 'node:fs';
import { expect, test } from 'vitest';

test.each([
  ['/', '../../src/pages/index.astro'],
  ['/es/', '../../src/pages/es/index.astro'],
])('defines a page for %s', (_route, page) => {
  expect(existsSync(new URL(page, import.meta.url))).toBe(true);
});
