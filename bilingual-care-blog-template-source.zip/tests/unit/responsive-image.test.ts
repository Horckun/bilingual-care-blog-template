import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const component = readFileSync(new URL('../../src/components/ResponsiveImage.astro', import.meta.url), 'utf8');
const budget = readFileSync(new URL('../../scripts/check-performance.mts', import.meta.url), 'utf8');

describe('responsive image safety', () => {
  it('does not invent local image variants', () => {
    expect(component).not.toContain('replace(/(\\.[a-z0-9]+)$/i');
    expect(component).toContain('sources?.filter');
  });

  it('validates every emitted local image source during the output audit', () => {
    expect(budget).toContain('Missing emitted image');
    expect(budget).toContain('srcset');
  });
});
