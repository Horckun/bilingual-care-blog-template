import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { validateAnalyticsAccessConfig } from '../../scripts/validate-analytics-access-config.mts';

describe('analytics Access deployment configuration', () => {
  it('allows the template placeholder only outside production', () => {
    const config = readFileSync(resolve(import.meta.dirname, '../../analytics-worker/wrangler.toml'), 'utf8');
    expect(config).toContain('binding = "ACCESS_JWT_VERIFIER"');
    expect(config).toContain('service = "REPLACE_WITH_PRIVATE_ACCESS_VERIFIER"');
    expect(validateAnalyticsAccessConfig(config, 'template').ok).toBe(true);
    expect(validateAnalyticsAccessConfig(config, 'preview').ok).toBe(true);
    expect(validateAnalyticsAccessConfig(config, 'production')).toEqual({
      ok: false,
      errors: ['Production analytics requires a real private Access verifier binding.'],
    });
  });

  it('accepts a non-placeholder binding for production', () => {
    const config = '[[services]]\nbinding = "ACCESS_JWT_VERIFIER"\nservice = "private-access-verifier"\n';
    expect(validateAnalyticsAccessConfig(config, 'production').ok).toBe(true);
  });
});
