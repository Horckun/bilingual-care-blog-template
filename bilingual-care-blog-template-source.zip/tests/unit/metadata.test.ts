import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { buildHreflang, buildRobots, getCanonicalUrl } from '../../src/utils/metadata.ts';
import { buildRssXml, buildSitemapXml } from '../../src/utils/xml.ts';

describe('metadata safety', () => {
  it('keeps preview output non-indexable and canonical-free', () => {
    expect(getCanonicalUrl('/es/blog/demo/', 'preview')).toBeNull();
    expect(buildRobots('preview')).toContain('noindex');
  });

  it('creates reciprocal production language alternatives', () => {
    expect(buildHreflang('/blog/demo/', '/es/blog/demo/', 'https://example.test')).toEqual([
      { lang: 'fr', href: 'https://example.test/blog/demo/' },
      { lang: 'es', href: 'https://example.test/es/blog/demo/' },
    ]);
  });

  it('maps every paired static page to an alternate in the shared layout', () => {
    const layout = readFileSync(new URL('../../src/layouts/BaseLayout.astro', import.meta.url), 'utf8');
    for (const route of ['/a-propos/', '/es/acerca-de/', '/contact/', '/es/contacto/', '/le-metier/', '/es/oficio/']) {
      expect(layout).toContain(`'${route}'`);
    }
  });

  it('uses XML escaping for feed text', () => {
    const rss = readFileSync(new URL('../../src/pages/rss.xml.ts', import.meta.url), 'utf8');
    expect(rss).toContain('buildRssXml');
    expect(rss).toContain('publishedAt: new Date(data.publishedAt)');
  });

  it('serializes published RSS entries and XML-reserved text safely', () => {
    const xml = buildRssXml({ title: 'Demo & notes', link: 'https://example.test/', description: 'A < B', items: [{ title: 'One & two', link: 'https://example.test/blog/demo/', description: 'Use <tags>', publishedAt: new Date('2026-01-02T00:00:00Z') }] });
    expect(xml).toContain('<item>');
    expect(xml).toContain('One &amp; two');
    expect(xml).toContain('Use &lt;tags&gt;');
  });

  it('serializes sitemap URL entries with XML escaping', () => {
    const xml = buildSitemapXml(['https://example.test/blog/demo/?q=a&b=c']);
    expect(xml).toContain('<url><loc>https://example.test/blog/demo/?q=a&amp;b=c</loc></url>');
  });

  it('keeps paired static pages wired to explicit alternate metadata', () => {
    const root = readFileSync(new URL('../../src/pages/index.astro', import.meta.url), 'utf8');
    const spanish = readFileSync(new URL('../../src/pages/es/index.astro', import.meta.url), 'utf8');
    expect(root).toContain("alternates={{ frPath: '/', esPath: '/es/' }}");
    expect(spanish).toContain("alternates={{ frPath: '/', esPath: '/es/' }}");
  });
});
