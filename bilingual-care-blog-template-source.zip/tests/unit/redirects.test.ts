import { describe, expect, it } from 'vitest';
import { validateRedirects } from '../../src/data/redirects.ts';

describe('redirect validation', () => {
  it('reports every inventoried URL without a redirect', () => {
    expect(validateRedirects([{ from: '/old/', to: '/blog/demo/', status: 301 }], ['/old/', '/missing/']).unmapped).toEqual(['/missing/']);
  });

  it('rejects duplicate and non-site redirect paths', () => {
    expect(validateRedirects([
      { from: '/old/', to: '/new/', status: 301 },
      { from: '/old/', to: 'https://outside.example/', status: 302 },
    ], ['/old/']).invalid).toHaveLength(2);
  });

  it('allows retained paths when represented as an identity mapping', () => {
    expect(validateRedirects([{ from: '/retained/', to: '/retained/', status: 301 }], ['/retained/']).unmapped).toEqual([]);
  });
});
