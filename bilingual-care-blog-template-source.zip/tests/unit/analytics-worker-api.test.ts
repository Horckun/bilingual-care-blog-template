import { describe, expect, it } from 'vitest';
import { createAnalyticsWorker } from '../../analytics-worker/src/index.ts';
import type { AnalyticsReport } from '../../src/analytics/types.ts';

const period = { type: 'weekly' as const, start: '2027-01-04', end: '2027-01-10' };
const report: AnalyticsReport = {
  id: 'report-weekly-2027-01-04-2027-01-10-v1', period,
  aggregate: { visits: 2, pageViews: 3, countries: [], referrers: [], metricStatus: { visits: 'available', pageViews: 'available', countries: 'available', referrers: 'available' } },
  generatedAt: '2027-01-11T08:00:00Z', summary: 'Safe aggregate report.',
};
const repository = { findByPeriod: async () => report, findPrevious: async () => undefined, save: async () => ({ report, created: false }), recordRun: async () => undefined };
const environment = {
  ANALYTICS_DB: {} as never, CLOUDFLARE_ANALYTICS_API_TOKEN: 'server-only-test-token', CLOUDFLARE_ACCOUNT_ID: 'test-account',
  ANALYTICS_OWNER_EMAIL: 'owner@example.invalid', ACCESS_ISSUER: 'https://access.example.invalid', ACCESS_AUDIENCE: 'test-audience',
  ACCESS_JWT_VERIFIER: { verify: async () => ({ email: 'owner@example.invalid', subject: 'owner' }) },
};

describe('protected analytics APIs', () => {
  it('denies missing identities and returns safe authenticated summary/download states', async () => {
    const worker = createAnalyticsWorker({ repository: () => repository });
    const denied = await worker.fetch(new Request('https://example.invalid/admin/estadisticas/api/summary'), environment);
    expect(denied.status).toBe(401);
    const summary = await worker.fetch(new Request('https://example.invalid/admin/estadisticas/api/summary', { headers: { 'Cf-Access-Jwt-Assertion': 'valid' } }), environment);
    expect(summary.status).toBe(200);
    expect((await summary.json()).mode).toBe('production');
    const download = await worker.fetch(new Request(`https://example.invalid/admin/estadisticas/api/reports/${report.id}`, { headers: { 'Cf-Access-Jwt-Assertion': 'valid' } }), environment);
    expect(download.headers.get('content-disposition')).toContain(`${report.id}.json`);
  });

  it('keeps invalid and unavailable report downloads private', async () => {
    const worker = createAnalyticsWorker({ repository: () => ({ ...repository, findByPeriod: async () => undefined }) });
    const headers = { 'Cf-Access-Jwt-Assertion': 'valid' };
    const missing = await worker.fetch(new Request(`https://example.invalid/admin/estadisticas/api/reports/${report.id}`, { headers }), environment);
    expect(missing.status).toBe(404);
    const invalid = await worker.fetch(new Request('https://example.invalid/admin/estadisticas/api/reports/not-a-report', { headers }), environment);
    expect(invalid.status).toBe(404);
  });
});
