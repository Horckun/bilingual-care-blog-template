import { describe, expect, it } from 'vitest';
import { resolve } from 'node:path';
import { parseImportOptions } from '../../scripts/import-wordpress-lib.ts';

describe('private migration importer safeguards', () => {
  it('defaults to dry-run and requires --write before any mutation', () => {
    const options = parseImportOptions(['--input', resolve(process.cwd(), 'package.json'), '--output', 'C:/private-blog'], 'C:/public-template');
    expect(options?.write).toBe(false);
  });

  it('rejects output inside the public template', () => {
    expect(parseImportOptions(['--input', resolve(process.cwd(), 'package.json'), '--output', 'C:/public-template/output'], 'C:/public-template')).toBeNull();
  });
});
