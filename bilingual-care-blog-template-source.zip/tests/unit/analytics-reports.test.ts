import { describe, expect, it } from 'vitest';
import { demoAnalyticsAggregate } from '../../src/analytics/fixtures.ts';
import { generateReport } from '../../src/analytics/reports.ts';
import type { ReportRepository, ReportRun } from '../../src/analytics/repository.ts';
import type { AnalyticsReport } from '../../src/analytics/types.ts';
import { MONTHLY_CRON, WEEKLY_CRON, runScheduledReport } from '../../analytics-worker/src/index.ts';
import type { AnalyticsProvider } from '../../src/analytics/provider.ts';

const weekly = { type: 'weekly' as const, start: '2027-01-04', end: '2027-01-10' };

function repository(existing?: AnalyticsReport): ReportRepository & { saved: number; runs: Array<{ status: string; cron: string }> } {
  let report: AnalyticsReport | undefined = existing;
  return {
    saved: 0,
    runs: [],
    async findByPeriod() { return report; },
    async findPrevious() { return undefined; },
    async save(next: AnalyticsReport) { const created = !report; report = report ?? next; if (created) this.saved += 1; return { report, created }; },
    async recordRun(run: ReportRun) { this.runs.push({ status: run.status, cron: run.cron }); },
  };
}

describe('scheduled analytics reports', () => {
  it('is idempotent for a repeated period', async () => {
    const store = repository();
    const provider: AnalyticsProvider = { async query() { return demoAnalyticsAggregate; } };
    const first = await generateReport(weekly, provider, store, '0 8 * * MON', () => new Date('2027-01-11T08:00:00Z'));
    const second = await generateReport(weekly, provider, store, '0 8 * * MON', () => new Date('2027-01-11T08:01:00Z'));
    expect(first.id).toBe(second.id);
    expect(store.saved).toBe(1);
  });

  it('records zero traffic safely', async () => {
    const store = repository();
    const provider: AnalyticsProvider = { async query() { return { ...demoAnalyticsAggregate, visits: 0, pageViews: 0 }; } };
    const report = await generateReport(weekly, provider, store, '0 8 * * MON');
    expect(report.summary).toContain('0 visits');
  });

  it('calculates deltas against the prior equivalent report', async () => {
    const prior = { id: 'prior', period: { type: 'weekly' as const, start: '2026-12-28', end: '2027-01-03' }, aggregate: { ...demoAnalyticsAggregate, visits: 10, pageViews: 20 }, generatedAt: '2027-01-04T08:00:00Z', summary: 'prior' };
    const store = repository();
    store.findPrevious = async () => prior;
    const provider: AnalyticsProvider = { async query() { return { ...demoAnalyticsAggregate, visits: 15, pageViews: 26 }; } };
    const report = await generateReport(weekly, provider, store, '0 8 * * MON');
    expect(report.delta).toEqual({ visits: 5, pageViews: 6 });
  });

  it('records a safe failed run without storing provider errors', async () => {
    const store = repository();
    const provider: AnalyticsProvider = { async query() { throw new Error('token=private-value'); } };
    await expect(generateReport(weekly, provider, store, '0 8 * * MON')).rejects.toThrow('Analytics provider query failed.');
    expect(store.runs.map((run: { status: string }) => run.status)).toContain('failed');
  });

  it('records only one generated status for concurrent saves', async () => {
    const store = repository();
    const provider: AnalyticsProvider = { async query() { return demoAnalyticsAggregate; } };
    await Promise.all([generateReport(weekly, provider, store, WEEKLY_CRON), generateReport(weekly, provider, store, WEEKLY_CRON)]);
    expect(store.runs.map((run: { status: string }) => run.status).filter((status: string) => status === 'generated')).toHaveLength(1);
  });

  it('dispatches weekly and monthly reports independently when Monday is day one', async () => {
    const store = repository();
    const provider: AnalyticsProvider = { async query() { return demoAnalyticsAggregate; } };
    const env = { ANALYTICS_DB: { prepare() { throw new Error('repository must be injected'); } }, CLOUDFLARE_ANALYTICS_API_TOKEN: 'test', CLOUDFLARE_ACCOUNT_ID: 'test' };
    const now = new Date('2027-03-01T08:00:00Z');
    expect(now.getUTCDay()).toBe(1);
    await runScheduledReport(WEEKLY_CRON, env, now, { provider, repository: store });
    await runScheduledReport(MONTHLY_CRON, env, now, { provider, repository: store });
    expect(store.runs.map((run: { cron: string }) => run.cron)).toEqual([WEEKLY_CRON, MONTHLY_CRON]);
    expect(store.runs.map((run: { status: string }) => run.status)).toContain('generated');
  });
});
