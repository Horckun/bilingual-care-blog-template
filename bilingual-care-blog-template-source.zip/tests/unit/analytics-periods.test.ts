import { describe, expect, it } from 'vitest';
import { getPreviousMonthlyPeriod, getPreviousWeeklyPeriod } from '../../src/analytics/periods.ts';
import { demoAnalyticsAggregate } from '../../src/analytics/fixtures.ts';

describe('analytics UTC reporting periods', () => {
  it('uses the previous complete Monday-Sunday week', () => {
    expect(getPreviousWeeklyPeriod(new Date('2027-01-04T08:00:00Z'))).toEqual({
      type: 'weekly', start: '2026-12-28', end: '2027-01-03',
    });
  });

  it('does not let a Sunday UTC clock move the report into a partial week', () => {
    expect(getPreviousWeeklyPeriod(new Date('2027-01-03T23:59:59Z'))).toEqual({
      type: 'weekly', start: '2026-12-21', end: '2026-12-27',
    });
  });

  it('uses the previous complete calendar month across a year boundary', () => {
    expect(getPreviousMonthlyPeriod(new Date('2027-01-01T08:00:00Z'))).toEqual({
      type: 'monthly', start: '2026-12-01', end: '2026-12-31',
    });
  });

  it('handles leap-year February in UTC', () => {
    expect(getPreviousMonthlyPeriod(new Date('2028-03-01T08:00:00Z'))).toEqual({
      type: 'monthly', start: '2028-02-01', end: '2028-02-29',
    });
  });

  it('provides deterministic aggregate-only local fixtures', () => {
    expect(demoAnalyticsAggregate.visits).toBeGreaterThan(0);
    expect(demoAnalyticsAggregate).not.toHaveProperty('ip');
    expect(demoAnalyticsAggregate).not.toHaveProperty('visitorId');
  });
});
