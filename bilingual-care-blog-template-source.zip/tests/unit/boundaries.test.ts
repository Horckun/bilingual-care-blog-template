import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { scanPublicTemplate } from '../../scripts/check-boundaries.mts';

const roots: string[] = [];
function fixture(files: Record<string, string>) {
  const root = mkdtempSync(join(tmpdir(), 'boundary-test-'));
  roots.push(root);
  for (const [path, content] of Object.entries(files)) {
    const target = join(root, path);
    mkdirSync(join(target, '..'), { recursive: true });
    writeFileSync(target, content, 'utf8');
  }
  return root;
}
afterEach(() => roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true })));

describe('public template boundaries', () => {
  it('allows neutral demo content and example domains', () => {
    expect(scanPublicTemplate(fixture({ 'src/content/articles/fr/demo.mdx': '---\ntitle: Demo\n---\nhttps://example.com' })).ok).toBe(true);
  });
  it('rejects credentials, analytics and real domains', () => {
    const report = scanPublicTemplate(fixture({ 'src/config.ts': 'API_KEY=abcd12345678\nconst id = "G-123456"\nhttps://real-site.invalid' }));
    expect(report.violations.map((item) => item.rule)).toEqual(expect.arrayContaining(['credential', 'analytics', 'domain']));
  });
  it('scans env examples and permits localhost ports', () => {
    const unsafe = scanPublicTemplate(fixture({ '.env.example': 'PUBLIC_SITE_URL=https://real-site.invalid\nAPI_KEY=abcd12345678' }));
    expect(unsafe.violations.map((item) => item.rule)).toEqual(expect.arrayContaining(['credential', 'domain']));
    expect(scanPublicTemplate(fixture({ 'src/config.ts': 'const url = "http://localhost:4322"' })).ok).toBe(true);
  });
  it('rejects private production content and paths', () => {
    const report = scanPublicTemplate(fixture({ 'production/article.mdx': 'client article' }));
    expect(report.violations.map((item) => item.rule)).toEqual(expect.arrayContaining(['private-content', 'unsafe-path']));
  });
  it('rejects client and real content or media paths', () => {
    const report = scanPublicTemplate(fixture({
      'content/client-story.mdx': 'Neutral-looking content',
      'assets/client-photo.jpg': 'binary fixture omitted',
      'content/real-article.mdx': 'Private content marker',
    }));
    expect(report.violations.filter((item) => item.rule === 'unsafe-path')).toHaveLength(3);
    expect(report.violations.some((item) => item.rule === 'private-content')).toBe(true);
  });
});
