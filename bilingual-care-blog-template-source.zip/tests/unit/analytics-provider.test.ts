import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { demoAnalyticsAggregate } from '../../src/analytics/fixtures.ts';
import {
  createCloudflareAnalyticsProvider,
  createFixtureAnalyticsProvider,
  normalizeProviderAggregate,
  type AnalyticsProvider,
} from '../../src/analytics/provider.ts';

describe('analytics provider boundary', () => {
  it('returns deterministic aggregate-only fixture data in local mode', async () => {
    const provider = createFixtureAnalyticsProvider();
    await expect(provider.query({ type: 'weekly', start: '2026-01-05', end: '2026-01-11' })).resolves.toEqual(demoAnalyticsAggregate);
  });

  it('preserves provider sampling and unavailable qualifiers', () => {
    const aggregate = normalizeProviderAggregate({
      visits: { value: 20, status: 'sampled' },
      pageViews: { value: null, status: 'unavailable' },
      countries: [],
      referrers: [],
    });

    expect(aggregate.visits).toBe(20);
    expect(aggregate.pageViews).toBe(0);
    expect(aggregate.metricStatus.visits).toBe('sampled');
    expect(aggregate.metricStatus.pageViews).toBe('unavailable');
  });

  it('keeps provider secrets outside the public provider interface', () => {
    const provider: AnalyticsProvider = createFixtureAnalyticsProvider();
    expect(JSON.stringify(provider)).not.toMatch(/token|account|secret/i);
  });

  it('queries GraphQL only through injected server transport and maps unavailable metrics', async () => {
    const requests: RequestInit[] = [];
    const provider = createCloudflareAnalyticsProvider({
      CLOUDFLARE_ANALYTICS_API_TOKEN: 'example_server_token_only',
      CLOUDFLARE_ACCOUNT_ID: 'example_account_only',
      fetch: async (_input, init) => {
        requests.push(init ?? {});
        return new Response(JSON.stringify({ data: { viewer: { accounts: [{ httpRequestsAdaptiveGroups: [{ sum: { visits: 7 } }] }] } } }), { status: 200 });
      },
    });
    const aggregate = await provider.query({ type: 'weekly', start: '2026-01-05', end: '2026-01-11' });
    expect(requests).toHaveLength(1);
    expect(aggregate.visits).toBe(7);
    expect(aggregate.metricStatus.pageViews).toBe('unavailable');
  });

  it('renders the beacon only after explicit production enablement and keeps server values out of the layout', () => {
    const beacon = readFileSync(resolve(import.meta.dirname, '../../src/analytics/beacon.astro'), 'utf8');
    const layout = readFileSync(resolve(import.meta.dirname, '../../src/layouts/BaseLayout.astro'), 'utf8');
    expect(beacon).toContain("mode === 'production' && enabled");
    expect(layout).not.toContain('CLOUDFLARE_ANALYTICS_API_TOKEN');
    expect(layout).not.toContain('CLOUDFLARE_ACCOUNT_ID');
    expect(layout).not.toContain('demoAnalyticsAggregate');
  });
});
