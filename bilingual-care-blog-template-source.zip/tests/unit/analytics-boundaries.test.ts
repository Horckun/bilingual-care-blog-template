import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { scanPublicTemplate } from '../../scripts/check-boundaries.mts';

const roots: string[] = [];

function fixture(files: Record<string, string>) {
  const root = mkdtempSync(join(tmpdir(), 'analytics-boundary-'));
  roots.push(root);
  for (const [path, content] of Object.entries(files)) {
    const target = join(root, path);
    mkdirSync(join(target, '..'), { recursive: true });
    writeFileSync(target, content, 'utf8');
  }
  return root;
}

afterEach(() => roots.splice(0).forEach((root) => rmSync(root, { recursive: true, force: true })));

describe('analytics public-template boundaries', () => {
  it('rejects preview tracking and analytics secrets in public files', () => {
    const report = scanPublicTemplate(fixture({
      '.env.example': 'PUBLIC_DEPLOYMENT_MODE=preview\nPUBLIC_ANALYTICS_ENABLED=true\nCLOUDFLARE_ANALYTICS_API_TOKEN=server-secret-value',
    }));
    expect(report.violations.map((item) => item.rule)).toEqual(expect.arrayContaining(['analytics', 'credential']));
  });

  it('allows disabled preview analytics and generic operator documentation', () => {
    const report = scanPublicTemplate(fixture({
      '.env.example': 'PUBLIC_DEPLOYMENT_MODE=preview\nPUBLIC_ANALYTICS_ENABLED=false\nPUBLIC_ANALYTICS_BEACON_TOKEN=',
      'docs/ANALYTICS.md': 'Store a server-only token in the private Worker environment.',
    }));
    expect(report.ok).toBe(true);
  });
});
