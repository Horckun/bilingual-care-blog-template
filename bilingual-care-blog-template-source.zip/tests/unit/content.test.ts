import { describe, expect, test } from 'vitest';
import { getLocalePath, type Locale, type LocaleSection } from '../../src/config/locales';
import { articleSchema, type ArticleData } from '../../src/config/article-schema';
import { readArticleSource } from '../../src/utils/article-source';
import { createArticleLookup, validateContent } from '../../src/utils/content';

const french: ArticleData = {
  id: 'journee-demo-fr',
  locale: 'fr',
  translationId: 'demo-day',
  slug: 'une-journee-demo',
  title: 'Une journée démo',
  description: 'Une page de démonstration.',
  publishedAt: '2025-01-15',
  updatedAt: '2025-01-16',
  cover: null,
  alt: null,
  category: 'demos',
  tags: ['demo'],
  draft: false,
};

const spanish: ArticleData = {
  ...french,
  id: 'dia-demo-es',
  locale: 'es',
  slug: 'un-dia-demo',
  title: 'Un día de muestra',
  description: 'Una página de demostración.',
};

function source(data: ArticleData, links: string[] = []) {
  return { file: `${data.locale}/${data.slug}.mdx`, data, links };
}

describe('article metadata', () => {
  test.each([
    { title: '   ' },
    { tags: ['  '] },
    { publishedAt: '2025-02-31' },
    { cover: '/images/demo.webp', alt: null },
    { cover: '', alt: null },
    { typo: true },
  ])('rejects invalid metadata %j', (overrides) => {
    expect(articleSchema.safeParse({ ...french, ...overrides }).success).toBe(false);
  });

  test('requires explicit cover and alt metadata for an article without a cover', () => {
    const { cover: _cover, ...withoutCover } = french;
    const { alt: _alt, ...withoutAlt } = french;
    expect(articleSchema.safeParse(withoutCover).success).toBe(false);
    expect(articleSchema.safeParse(withoutAlt).success).toBe(false);
  });
});

describe('bilingual article lookup and validation', () => {
  test('matches translated articles by translation ID across localized slugs', () => {
    const entries = [{ data: french }, { data: spanish }];
    const lookup = createArticleLookup(entries);

    expect(validateContent([source(french), source(spanish)]).ok).toBe(true);
    expect(lookup.getArticleByLocaleSlug('es', 'un-dia-demo')).toEqual(entries[1]);
    expect(lookup.getArticleByLocaleSlug('fr', 'un-dia-demo')).toBeUndefined();
    expect(lookup.getTranslation(french, 'es')).toEqual(entries[1]);
    expect(lookup.getTranslation(spanish, 'fr')).toEqual(entries[0]);
  });

  test('rejects two articles sharing a locale and translation ID', () => {
    const secondSpanishArticle = { ...spanish, id: 'otra-demo-es', slug: 'otra-demo' };
    const result = validateContent([source(french), source(spanish), source(secondSpanishArticle)]);

    expect(result.ok).toBe(false);
    expect(result.errors).toEqual([expect.stringContaining('otra-demo.mdx')]);
  });

  test('allows an untranslated article and leaves its alternate undefined', () => {
    const lookup = createArticleLookup([{ data: french }]);

    expect(validateContent([source(french)]).ok).toBe(true);
    expect(lookup.getTranslation(french, 'es')).toBeUndefined();
  });

  test('keeps draft translations unavailable through either lookup', () => {
    const lookup = createArticleLookup([{ data: french }, { data: { ...spanish, draft: true } }]);

    expect(lookup.getTranslation(french, 'es')).toBeUndefined();
    expect(lookup.getArticleByLocaleSlug('es', 'un-dia-demo')).toBeUndefined();
  });

  test('rejects an article link when the Spanish destination is absent or still a draft', () => {
    const linkingSource = source(french, ['/es/blog/un-dia-demo/?demo=1#contenido']);

    expect(validateContent([linkingSource]).ok).toBe(false);
    expect(validateContent([linkingSource, source({ ...spanish, draft: true })]).ok).toBe(false);
    expect(validateContent([linkingSource, source(spanish)]).ok).toBe(true);
  });

  test('reports a malformed link and keeps checking links in other files', () => {
    const result = validateContent([
      source(french, ['/\\']),
      source(spanish, ['/blog/autre-demo/']),
    ]);

    expect(result.ok).toBe(false);
    expect(result.errors).toEqual([
      expect.stringContaining('fr/une-journee-demo.mdx: malformed link'),
      expect.stringContaining('es/un-dia-demo.mdx: article link /blog/autre-demo/'),
    ]);
  });

  test('rejects an article in a directory for the other locale', () => {
    expect(validateContent([{ ...source(spanish), file: 'fr/un-dia-demo.mdx' }]).ok).toBe(false);
  });

  test('rejects duplicate article IDs and duplicate routes', () => {
    const duplicateId = { ...spanish, id: french.id };
    const duplicateSlug = { ...spanish, id: 'otra-demo-es', translationId: 'other-demo' };

    expect(validateContent([source(french), source(duplicateId)]).ok).toBe(false);
    expect(validateContent([source(spanish), { ...source(duplicateSlug), file: 'es/otra-demo.mdx' }]).ok).toBe(false);
  });
});

test.each([
  { locale: 'fr', expected: '/' },
  { locale: 'es', expected: '/es/' },
  { locale: 'fr', section: 'blog', expected: '/blog/' },
  { locale: 'es', section: 'blog', expected: '/es/blog/' },
  { locale: 'fr', section: 'blog', slug: 'une-journee-demo', expected: '/blog/une-journee-demo/' },
  { locale: 'es', section: 'blog', slug: 'un-dia-demo', expected: '/es/blog/un-dia-demo/' },
  { locale: 'fr', section: 'profession', expected: '/le-metier/' },
  { locale: 'es', section: 'profession', expected: '/es/oficio/' },
] satisfies { locale: Locale; section?: LocaleSection; slug?: string; expected: string }[])(
  'routes to $expected',
  ({ locale, section, slug, expected }) => {
    expect(getLocalePath(locale, section, slug)).toBe(expected);
  },
);

test('collects links emitted by Markdown and MDX and ignores code and unused definitions', () => {
  const content = [
    '---',
    'title: Démonstration',
    '---',
    '',
    '[Version espagnole](/es/blog/un-dia-demo/)',
    '',
    '[Autre exemple][demo]',
    '',
    '[demo]: /es/blog/otra-demo/',
    '[unused]: /es/blog/unused-demo/',
    '',
    '<a href="/es/blog/ejemplo-demo/">Ejemplo</a>',
    '',
    '`[Code](/es/blog/code-demo/)`',
  ].join('\n');

  expect(readArticleSource('fr/demo.mdx', content)).toEqual({
    file: 'fr/demo.mdx',
    data: { title: 'Démonstration' },
    links: ['/es/blog/un-dia-demo/', '/es/blog/otra-demo/', '/es/blog/ejemplo-demo/'],
  });
});

test('validates JSX string literal links without evaluating JavaScript in the article', () => {
  const content = [
    '---',
    'title: Demo',
    '---',
    '',
    "<a href={'/es/blog/ausente/'}>Ausente</a>",
    '',
    '<a href={missingVariable}>Dinámico</a>',
  ].join('\n');
  const parsed = readArticleSource('fr/demo.mdx', content);

  expect(parsed.links).toEqual(['/es/blog/ausente/']);
  expect(validateContent([{ ...parsed, data: french }]).errors).toEqual([
    expect.stringContaining('fr/demo.mdx: article link /es/blog/ausente/'),
  ]);
});
