import { expect, test } from '@playwright/test';

test('navigates to the Spanish translation from a French article', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('/blog/une-journee-demo/');
  await expect(page.locator('[data-article-prose]')).toHaveCSS('max-width', '960px');
  await page.locator('.translation').click();
  await expect(page).toHaveURL('/es/blog/un-dia-demo/');
  await expect(page.locator('html')).toHaveAttribute('lang', 'es');
});

test('filters archives and excludes identifiable drafts', async ({ page }) => {
  await page.goto('/blog/une-journee-demo/');
  await page.getByRole('link', { name: 'demonstrations' }).click();
  await expect(page).toHaveURL('/categorie/demonstrations/');
  await expect(page.locator('main')).toContainText(/Une journ\u00e9e de d\u00e9monstration/);
  await expect(page.locator('main')).not.toContainText(/Brouillon de d\u00e9monstration/);

  await page.goto('/es/blog/un-dia-demo/');
  await page.getByRole('link', { name: '#ejemplo' }).click();
  await expect(page).toHaveURL('/es/etiquetas/ejemplos/');
  await expect(page.locator('main')).toContainText(/Un d\u00eda de demostraci\u00f3n/);
  await expect(page.locator('main')).not.toContainText(/Borrador de demostraci\u00f3n/);
});
