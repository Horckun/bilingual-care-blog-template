import { expect, test } from '@playwright/test';

test.describe('global shell', () => {
  test('renders the French accessible navigation at desktop width', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/');

    await expect(page.getByRole('link', { name: 'Aller au contenu principal' })).toBeVisible();
    await expect(page.getByRole('navigation', { name: 'Navigation principale' })).toContainText('Accueil');
    await expect(page.getByRole('link', { name: 'Español' })).toHaveAttribute('href', '/es/');
  });

  test('gives the desktop hero title a readable measure', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/');

    const title = page.getByRole('heading', { level: 1 });
    await expect(title).toBeVisible();
    expect((await title.boundingBox())?.width).toBeGreaterThan(220);
  });

  test('renders Spanish labels, paths, and a keyboard-usable mobile menu', async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/es/');

    await expect(page.getByRole('link', { name: 'Saltar al contenido' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Menú principal' })).toBeVisible();
    await page.getByRole('button', { name: 'Menú principal' }).press('Enter');
    await expect(page.getByRole('navigation', { name: 'Navegación principal' })).toContainText('Inicio');
    await expect(page.getByRole('link', { name: 'Blog', exact: true })).toHaveAttribute('href', '/es/blog/');
    await expect(page.getByRole('link', { name: 'Français' })).toHaveAttribute('href', '/');
  });
});
