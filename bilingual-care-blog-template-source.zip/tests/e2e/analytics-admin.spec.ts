import { expect, test } from '@playwright/test';

const summaryUrl = '**/admin/estadisticas/api/summary';
const reportPath = '/admin/estadisticas/api/reports/report-weekly-2026-01-01-2026-01-07-v1';

test('the private analytics page never embeds metrics in static HTML', async ({ page }) => {
  await page.goto('/admin/estadisticas/');
  await expect(page.getByRole('heading', { name: /estad\u00edsticas privadas/i })).toBeVisible();
  await expect(page.getByText('128')).toHaveCount(0);
});

test('the production browser view shows a denial state without Access', async ({ page }) => {
  await page.route(summaryUrl, (route) => route.fulfill({ status: 401 }));
  await page.goto('/admin/estadisticas/');
  await expect(page.locator('#analytics-dashboard')).toHaveAttribute('data-state', 'denied');
  await expect(page.getByText(/acceso denegado/i)).toBeVisible();
});

test('the explicit mocked owner view displays a server response and permits a report download', async ({ page }) => {
  await page.route(summaryUrl, (route) => route.fulfill({ contentType: 'application/json', body: JSON.stringify({ aggregate: { pageViews: 12, visits: 5 } }) }));
  await page.route(`**${reportPath}`, (route) => route.fulfill({ status: 200, headers: { 'content-disposition': 'attachment; filename="weekly.json"' }, body: '{}' }));
  await page.goto('/admin/estadisticas/');
  await expect(page.locator('#analytics-dashboard')).toHaveAttribute('data-state', 'ready');
  await expect(page.getByText(/12 p\u00e1ginas vistas/i)).toBeVisible();
  const download = await page.evaluate(async (path) => {
    const response = await fetch(path);
    return { status: response.status, disposition: response.headers.get('content-disposition') };
  }, reportPath);
  expect(download.status).toBe(200);
  expect(download.disposition).toContain('attachment');
});

test('the browser renders empty and provider-error states', async ({ page }) => {
  await page.route(summaryUrl, (route) => route.fulfill({ contentType: 'application/json', body: '{}' }));
  await page.goto('/admin/estadisticas/');
  await expect(page.locator('#analytics-dashboard')).toHaveAttribute('data-state', 'empty');
  await page.unroute(summaryUrl);
  await page.route(summaryUrl, (route) => route.fulfill({ status: 503 }));
  await page.reload();
  await expect(page.locator('#analytics-dashboard')).toHaveAttribute('data-state', 'error');
});

test('the protected dashboard remains usable on mobile', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.route(summaryUrl, (route) => route.fulfill({ status: 401 }));
  await page.goto('/admin/estadisticas/');
  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: /saltar al contenido/i })).toBeVisible();
  await expect(page.locator('#analytics-dashboard')).toHaveAttribute('data-state', 'denied');
});
