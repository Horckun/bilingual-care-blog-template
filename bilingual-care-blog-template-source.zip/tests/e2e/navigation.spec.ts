import { expect, test } from '@playwright/test';

const frenchLinks = [
  ['Accueil', '/'], ['Blog', '/blog/'], ['Le m\u00e9tier', '/le-metier/'],
  ['Questions', '/questions/'], ['\u00c0 propos', '/a-propos/'], ['Contact', '/contact/'],
] as const;

const spanishLinks = [
  ['Inicio', '/es/'], ['Blog', '/es/blog/'], ['Oficio', '/es/oficio/'],
  ['Preguntas', '/es/preguntas/'], ['Acerca de', '/es/acerca-de/'], ['Contacto', '/es/contacto/'],
] as const;

test('French primary navigation remains within French routes', async ({ page }) => {
  await page.goto('/');
  const nav = page.getByRole('navigation', { name: 'Navigation principale', exact: true });
  for (const [label, href] of frenchLinks) await expect(nav.getByRole('link', { name: label, exact: true })).toHaveAttribute('href', href);
  await expect(page.locator('header').getByRole('link', { name: 'Espa\u00f1ol', exact: true })).toHaveAttribute('href', '/es/');
});

test('primary navigation activates the selected French destination', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('navigation', { name: 'Navigation principale', exact: true }).getByRole('link', { name: 'Questions', exact: true }).click();
  await expect(page).toHaveURL(/\/questions\/$/);
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
});

test('keyboard focus reaches the Spanish primary navigation', async ({ page }) => {
  await page.goto('/es/');
  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'Saltar al contenido', exact: true })).toBeFocused();
  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'Cuaderno biling\u00fce', exact: true })).toBeFocused();
});

test('Spanish primary navigation remains within Spanish routes', async ({ page }) => {
  await page.goto('/es/');
  const nav = page.getByRole('navigation', { name: 'Navegaci\u00f3n principal', exact: true });
  for (const [label, href] of spanishLinks) await expect(nav.getByRole('link', { name: label, exact: true })).toHaveAttribute('href', href);
  await expect(page.locator('header').getByRole('link', { name: 'Fran\u00e7ais', exact: true })).toHaveAttribute('href', '/');
});

test('core locale pages provide a shared shell and matching article indexes', async ({ page }) => {
  for (const path of ['/blog/', '/le-metier/', '/questions/', '/a-propos/', '/contact/', '/es/blog/', '/es/oficio/', '/es/preguntas/', '/es/acerca-de/', '/es/contacto/']) {
    await page.goto(path);
    await expect(page.locator('main')).toBeVisible();
    await expect(page.locator('header')).toBeVisible();
  }
  await page.goto('/blog/');
  await expect(page.getByRole('link', { name: /Une journ\u00e9e/i })).toHaveAttribute('href', /\/blog\//);
  await page.goto('/es/blog/');
  await expect(page.getByRole('link', { name: /d\u00eda/i })).toHaveAttribute('href', /\/es\/blog\//);
});
