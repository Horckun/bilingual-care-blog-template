import { expect, test } from '@playwright/test';

test.use({ javaScriptEnabled: false });

test('navigates between the French and Spanish pages without JavaScript', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('html')).toHaveAttribute('lang', 'fr');
  await expect(page.getByRole('main')).toBeVisible();

  await page.getByRole('link', { name: 'Español' }).click();
  await expect(page).toHaveURL('/es/');
  await expect(page.locator('html')).toHaveAttribute('lang', 'es');
  await expect(page.getByRole('main')).toBeVisible();

  await page.getByRole('link', { name: 'Français' }).click();
  await expect(page).toHaveURL('/');
});
