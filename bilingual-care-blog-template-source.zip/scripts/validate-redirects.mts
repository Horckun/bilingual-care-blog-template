import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { validateRedirects, type RedirectEntry } from '../src/data/redirects.ts';

function usage() {
  console.log('Usage: node --experimental-strip-types scripts/validate-redirects.mts <inventory.txt> <redirects.json>');
  console.log('inventory.txt contains one legacy site path per line. redirects.json contains RedirectEntry objects.');
}

const [inventoryFile, redirectsFile] = process.argv.slice(2);
if (!inventoryFile || !redirectsFile || inventoryFile === '--help') {
  usage();
  process.exit(inventoryFile === '--help' ? 0 : 1);
}

const inventory = readFileSync(resolve(inventoryFile), 'utf8').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
const entries = JSON.parse(readFileSync(resolve(redirectsFile), 'utf8')) as RedirectEntry[];
const result = validateRedirects(entries, inventory);
console.log(JSON.stringify(result, null, 2));
process.exit(result.unmapped.length || result.invalid.length ? 1 : 0);
