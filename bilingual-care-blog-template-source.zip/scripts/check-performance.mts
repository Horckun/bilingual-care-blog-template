import { readdir, readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.argv[2] ?? 'dist';
const documentLimit = 350 * 1024;
const imageLimit = 220 * 1024;

async function scan(dir: string): Promise<string[]> {
  const entries = await readdir(dir, { withFileTypes: true });
  return (await Promise.all(entries.map((entry) => entry.isDirectory() ? scan(join(dir, entry.name)) : [join(dir, entry.name)]))).flat();
}

const output = await scan(root);
const violations: string[] = [];
for (const file of output) {
  const isImage = /\.(avif|webp|png|jpe?g)$/i.test(file);
  if ((await stat(file)).size > (isImage ? imageLimit : documentLimit)) violations.push(file);
}
const pages = await Promise.all(output.filter((file) => file.endsWith('.html')).map((file) => readFile(file, 'utf8')));
if (pages.some((page) => /<img(?![^>]*\bwidth=|[^>]*\bheight=)/.test(page))) violations.push('HTML image missing dimensions');
for (const page of pages) {
  const imageTags = page.match(/<img\b[^>]*>/g) ?? [];
  for (const tag of imageTags) {
    const sources = [...tag.matchAll(/\b(?:src|srcset)="([^"]+)"/g)].flatMap((match) => match[1].split(',').map((candidate) => candidate.trim().split(/\s+/)[0]));
    for (const source of sources) {
      if (!source.startsWith('/')) continue;
      const localPath = join(root, source.replace(/[?#].*$/, '').replace(/^\//, ''));
      try { await stat(localPath); } catch { violations.push(`Missing emitted image: ${source}`); }
    }
  }
}
if (violations.length) throw new Error(`Performance budget exceeded: ${violations.join(', ')}`);
console.log(`Performance budget passed: ${output.length} files checked.`);
