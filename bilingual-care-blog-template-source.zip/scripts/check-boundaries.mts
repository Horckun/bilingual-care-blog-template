import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { relative, resolve, sep } from 'node:path';

export type BoundaryViolation = {
  file: string;
  rule: 'credential' | 'analytics' | 'domain' | 'private-content' | 'unsafe-path';
  message: string;
};

export type BoundaryReport = { ok: boolean; violations: BoundaryViolation[] };

const ignored = new Set(['.git', '.astro', '.tools', 'dist', 'node_modules', 'playwright-report', 'test-results', 'tests', 'package-lock.json']);
const textExtensions = new Set(['.astro', '.css', '.json', '.md', '.mdx', '.mjs', '.mts', '.svg', '.toml', '.ts', '.txt', '.yml', '.yaml']);
const permittedDomains = new Set(['127.0.0.1:4322', 'example.com', 'example.org', 'localhost', 'schema.org', 'www.sitemaps.org', 'static.cloudflareinsights.com', 'api.cloudflare.com', 'access-verifier.internal']);

function walk(root: string, current = root): string[] {
  return readdirSync(current, { withFileTypes: true }).flatMap((entry) => {
    if (ignored.has(entry.name)) return [];
    const target = resolve(current, entry.name);
    if (entry.isDirectory()) return walk(root, target);
    return [target];
  });
}

function add(violations: BoundaryViolation[], file: string, rule: BoundaryViolation['rule'], message: string) {
  violations.push({ file, rule, message });
}

export function scanPublicTemplate(root: string): BoundaryReport {
  const absoluteRoot = resolve(root);
  const violations: BoundaryViolation[] = [];
  for (const file of walk(absoluteRoot)) {
    const relativeFile = relative(absoluteRoot, file).split(sep).join('/');
    if (relativeFile === 'scripts/check-boundaries.mts') continue;
    const name = file.slice(file.lastIndexOf(sep) + 1);
    const extension = name.slice(name.lastIndexOf('.'));
    const text = textExtensions.has(extension) || name === '.env.example' ? readFileSync(file, 'utf8') : '';
    const credentialScanText = relativeFile === 'src/layouts/BaseLayout.astro'
      ? text.replace(/const analyticsBeaconToken = import\.meta\.env\.PUBLIC_ANALYTICS_BEACON_TOKEN;/, '')
      : text;
    if (/(?:^|[^A-Za-z0-9])(?:api[_-]?key|secret|password|(?:access|analytics)(?:[_-]?api)?[_-]?token)\s*[:=]\s*(?!['"]?(?:your_|example_|\$\{|$))['"]?[^\s'"`]{8,}/im.test(credentialScanText)) add(violations, relativeFile, 'credential', 'Possible credential found.');
    if (/\b(?:G-|UA-|plausible\.|umami\.is|posthog\.com|matomo\.)/i.test(text)) add(violations, relativeFile, 'analytics', 'Production analytics identifier or endpoint found.');
    if (/^\s*PUBLIC_ANALYTICS_ENABLED\s*=\s*true\s*$/mi.test(text) && /PUBLIC_DEPLOYMENT_MODE\s*=\s*(?:preview|local)/i.test(text)) add(violations, relativeFile, 'analytics', 'Analytics tracking must remain disabled in local and preview configuration.');
    const domains = [...text.matchAll(/https?:\/\/([^/\s'"`]+)/gi)].map((match) => match[1].toLowerCase());
    if (domains.some((domain) => !permittedDomains.has(domain) && !/^localhost(?::\d+)?(?:\$\{[^}]+\})?$/.test(domain))) add(violations, relativeFile, 'domain', 'Non-demo domain found.');
    if (/\b(?:private[-_ ]?content|client[-_ ]?(?:article|story|photo|media)|real[-_ ]?(?:article|story|photo|media)|production[-_ ]?media)\b/i.test(text)) add(violations, relativeFile, 'private-content', 'Private production content marker found.');
    if (/(?:^|\/)(?:private|production)(?:\/|$)|(?:^|\/)(?:content|assets)\/(?:client|real|production)[-_]/i.test(relativeFile)) add(violations, relativeFile, 'unsafe-path', 'Private or production path found in public template.');
  }
  return { ok: violations.length === 0, violations };
}

if (import.meta.url === `file:///${process.argv[1]?.replace(/\\/g, '/')}`) {
  const root = process.argv[2] ? resolve(process.argv[2]) : resolve(import.meta.dirname, '..');
  if (!existsSync(root) || !statSync(root).isDirectory()) throw new Error(`Template root not found: ${root}`);
  const report = scanPublicTemplate(root);
  console.log(JSON.stringify(report, null, 2));
  process.exit(report.ok ? 0 : 1);
}
