import { existsSync } from 'node:fs';
import { relative, resolve } from 'node:path';

export interface ImportOptions {
  input: string;
  output: string;
  write: boolean;
}

export function isWithinPath(candidate: string, parent: string) {
  const relation = relative(resolve(parent), resolve(candidate));
  return relation === '' || (!relation.startsWith('..') && !relation.includes(':'));
}

export function parseImportOptions(args: readonly string[], templateRoot: string): ImportOptions | null {
  const valueFor = (flag: string) => {
    const index = args.indexOf(flag);
    return index === -1 ? undefined : args[index + 1];
  };
  const input = valueFor('--input');
  const output = valueFor('--output');
  if (!input || !output || !existsSync(resolve(input)) || isWithinPath(output, templateRoot)) return null;

  return { input: resolve(input), output: resolve(output), write: args.includes('--write') };
}
