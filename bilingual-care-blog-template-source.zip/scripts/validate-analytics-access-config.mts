import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

export type AnalyticsAccessDeploymentMode = 'template' | 'preview' | 'production';

export function validateAnalyticsAccessConfig(config: string, mode: AnalyticsAccessDeploymentMode) {
  const hasBinding = /binding\s*=\s*["']ACCESS_JWT_VERIFIER["']/.test(config);
  const service = config.match(/service\s*=\s*["']([^"']+)["']/)?.[1];
  const errors: string[] = [];

  if (!hasBinding) errors.push('Missing ACCESS_JWT_VERIFIER service binding.');
  if (!service) errors.push('Missing ACCESS_JWT_VERIFIER service value.');
  if (mode === 'production' && (!service || service.includes('REPLACE_'))) {
    errors.push('Production analytics requires a real private Access verifier binding.');
  }

  return { ok: errors.length === 0, errors };
}

function readMode(value: string | undefined): AnalyticsAccessDeploymentMode {
  return value === 'production' ? 'production' : value === 'preview' ? 'preview' : 'template';
}

if (process.argv[1]?.endsWith('validate-analytics-access-config.mts')) {
  const config = readFileSync(resolve(process.cwd(), 'analytics-worker/wrangler.toml'), 'utf8');
  const result = validateAnalyticsAccessConfig(config, readMode(process.env.ANALYTICS_DEPLOYMENT_MODE));
  if (!result.ok) {
    console.error(result.errors.join('\n'));
    process.exitCode = 1;
  }
}
