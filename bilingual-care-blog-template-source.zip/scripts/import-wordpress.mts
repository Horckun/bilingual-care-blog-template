import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, resolve } from 'node:path';
import { parseImportOptions } from './import-wordpress-lib.ts';

function usage() {
  console.log('Usage: node --experimental-strip-types scripts/import-wordpress.mts --input <export.xml> --output <private-output-directory> [--write]');
  console.log('This offline utility never connects to WordPress. It defaults to dry-run and refuses output inside this public template.');
}

const args = process.argv.slice(2);
if (args.includes('--help')) { usage(); process.exit(0); }
const options = parseImportOptions(args, resolve('.'));
if (!options) { usage(); process.exit(1); }
const { input, output } = options;
const dryRun = !options.write;

const xml = readFileSync(resolve(input), 'utf8');
const report = {
  source: basename(input),
  importedAt: new Date().toISOString(),
  itemCount: (xml.match(/<item>/g) ?? []).length,
  dryRun,
  note: 'Offline inventory only. Review and transform content privately before publishing.',
};
if (!dryRun) {
  mkdirSync(resolve(output), { recursive: true });
  writeFileSync(resolve(output, 'migration-report.json'), `${JSON.stringify(report, null, 2)}\n`, 'utf8');
}
console.log(JSON.stringify(report, null, 2));
