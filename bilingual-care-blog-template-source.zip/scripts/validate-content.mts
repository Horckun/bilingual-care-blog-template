import { readdir, readFile } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readArticleSource } from '../src/utils/article-source.ts';
import { validateContent, type ArticleSource } from '../src/utils/content.ts';

const root = fileURLToPath(new URL('../src/content/articles/', import.meta.url));
const entries = await readdir(root, { recursive: true, withFileTypes: true });
const files = entries
  .filter((entry) => entry.isFile() && entry.name.endsWith('.mdx'))
  .map((entry) => join(entry.parentPath, entry.name))
  .sort();

const sources: ArticleSource[] = [];
const readErrors: string[] = [];

for (const path of files) {
  const file = relative(root, path).split(sep).join('/');
  try {
    sources.push(readArticleSource(file, await readFile(path, 'utf8')));
  } catch (error) {
    readErrors.push(`${file}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

const { errors } = validateContent(sources);
if (readErrors.length || errors.length) {
  console.error([...readErrors, ...errors].join('\n'));
  process.exitCode = 1;
} else {
  console.log(`Validated ${sources.length} article(s).`);
}
