import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';

const outputRoot = resolve(process.argv[2] ?? 'dist');

if (!existsSync(outputRoot)) {
  throw new Error(`Build directory does not exist: ${outputRoot}`);
}

function files(directory: string): string[] {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? files(path) : [path];
  });
}

const htmlFiles = files(outputRoot).filter((file) => file.endsWith('.html'));
const missing: string[] = [];

for (const file of htmlFiles) {
  const html = readFileSync(file, 'utf8');
  for (const match of html.matchAll(/(?:href|src)=["']([^"']+)["']/g)) {
    const href = match[1];
    if (!href.startsWith('/') || href.startsWith('//') || href.includes('://') || href.startsWith('/#')) continue;
    const path = href.split(/[?#]/, 1)[0];
    const candidates = [join(outputRoot, path), join(outputRoot, path, 'index.html'), join(outputRoot, `${path}.html`)];
    if (!candidates.some(existsSync)) missing.push(`${relative(outputRoot, file)} -> ${href}`);
  }
}

if (missing.length) {
  throw new Error(`Broken local links:\n${missing.join('\n')}`);
}

console.log(`Checked ${htmlFiles.length} HTML file(s): no broken local links.`);
