import { MONTHLY_CRON, WEEKLY_CRON } from '../analytics-worker/src/index.ts';

console.log(`Scheduled report simulation prepared for ${WEEKLY_CRON} and ${MONTHLY_CRON}. Configure a private D1 database before executing Worker jobs.`);
