import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { articleSchema } from './config/article-schema.ts';

const articles = defineCollection({
  loader: glob({
    base: './src/content/articles',
    pattern: '**/*.mdx',
    // File paths keep entries distinct when both languages use the same slug.
    generateId: ({ entry }) => entry,
  }),
  schema: articleSchema,
});

export const collections = { articles };
