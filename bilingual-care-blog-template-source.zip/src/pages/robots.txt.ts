import type { APIRoute } from 'astro';
import { deploymentMode, siteUrl } from '../config/site.ts';

export const GET: APIRoute = () => new Response(
  deploymentMode === 'production' ? `User-agent: *\nAllow: /\n${siteUrl ? `Sitemap: ${siteUrl}/sitemap-index.xml\n` : ''}` : 'User-agent: *\nDisallow: /\n',
  { headers: { 'Content-Type': 'text/plain; charset=utf-8' } },
);
