import type { APIRoute } from 'astro';
import { getCollection } from 'astro:content';
import { deploymentMode, siteUrl, siteName } from '../config/site.ts';
import { buildRssXml } from '../utils/xml.ts';
export const GET: APIRoute = async () => {
  if (deploymentMode !== 'production' || !siteUrl) return new Response('', { headers: { 'Content-Type': 'application/rss+xml; charset=utf-8' } });
  const entries = (await getCollection('articles')).filter(({ data }) => !data.draft);
  const items = entries.map(({ data }) => ({ title: data.title, link: `${siteUrl}${data.locale === 'fr' ? `/blog/${data.slug}/` : `/es/blog/${data.slug}/`}`, description: data.description, publishedAt: new Date(data.publishedAt) }));
  return new Response(buildRssXml({ title: siteName, link: siteUrl, description: 'Neutral bilingual demonstration feed.', items }), { headers: { 'Content-Type': 'application/rss+xml; charset=utf-8' } });
};
