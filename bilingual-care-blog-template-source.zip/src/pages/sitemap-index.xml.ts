import type { APIRoute } from 'astro';
import { getCollection } from 'astro:content';
import { deploymentMode, siteUrl } from '../config/site.ts';
import { buildSitemapXml } from '../utils/xml.ts';
export const GET: APIRoute = async () => {
  if (deploymentMode !== 'production' || !siteUrl) return new Response('', { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
  const pages = ['/', '/es/', '/blog/', '/es/blog/'];
  for (const { data } of await getCollection('articles')) if (!data.draft) pages.push(data.locale === 'fr' ? `/blog/${data.slug}/` : `/es/blog/${data.slug}/`);
  return new Response(buildSitemapXml(pages.map((path) => `${siteUrl}${path}`)), { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
};
