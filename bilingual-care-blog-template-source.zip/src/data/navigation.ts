import { getLocalePath, type Locale, type LocaleSection } from '../config/locales';

type NavigationItem = {
  key: LocaleSection;
  label: Record<Locale, string>;
};

const primaryNavigation: NavigationItem[] = [
  { key: 'blog', label: { fr: 'Blog', es: 'Blog' } },
  { key: 'profession', label: { fr: 'Le métier', es: 'Oficio' } },
  { key: 'questions', label: { fr: 'Questions', es: 'Preguntas' } },
  { key: 'about', label: { fr: 'À propos', es: 'Acerca de' } },
  { key: 'contact', label: { fr: 'Contact', es: 'Contacto' } },
];

export function getPrimaryNavigation(locale: Locale) {
  return [
    { label: locale === 'fr' ? 'Accueil' : 'Inicio', href: getLocalePath(locale) },
    ...primaryNavigation.map((item) => ({ label: item.label[locale], href: getLocalePath(locale, item.key) })),
  ];
}

export const footerCopy: Record<Locale, string> = {
  fr: 'Un modèle de blog bilingue indépendant, pensé pour une lecture claire et durable.',
  es: 'Una plantilla de blog bilingüe independiente, pensada para una lectura clara y duradera.',
};
