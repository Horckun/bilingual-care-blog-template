export interface RedirectEntry {
  from: string;
  to: string;
  status: 301 | 302;
}

export interface RedirectValidationResult {
  unmapped: string[];
  invalid: string[];
}

function isSitePath(value: string) {
  return value.startsWith('/') && !value.startsWith('//');
}

export function validateRedirects(entries: readonly RedirectEntry[], inventory: readonly string[]): RedirectValidationResult {
  const invalid: string[] = [];
  const targets = new Map<string, RedirectEntry>();

  for (const entry of entries) {
    if (targets.has(entry.from)) invalid.push(`duplicate source ${entry.from}`);
    if (!isSitePath(entry.from) || !isSitePath(entry.to)) {
      invalid.push(`${entry.from} -> ${entry.to}`);
      continue;
    }
    targets.set(entry.from, entry);
  }

  return {
    unmapped: [...new Set(inventory)].filter((path) => !targets.has(path)),
    invalid,
  };
}

// The public template intentionally has no legacy routes. Add real redirects only in the private production repository.
export const redirects: readonly RedirectEntry[] = [];
