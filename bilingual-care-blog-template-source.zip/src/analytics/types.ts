export type ReportPeriodType = 'weekly' | 'monthly';

export interface ReportPeriod {
  type: ReportPeriodType;
  /** Inclusive UTC date in YYYY-MM-DD format. */
  start: string;
  /** Inclusive UTC date in YYYY-MM-DD format. */
  end: string;
}

export type AnalyticsMetricStatus = 'available' | 'sampled' | 'unavailable';

export interface AnalyticsMetric {
  value: number | null;
  status: AnalyticsMetricStatus;
}

/** Aggregate-only metrics. Never add IPs, identifiers, headers or form data here. */
export interface AnalyticsAggregate {
  visits: number;
  pageViews: number;
  countries: Array<{ country: string; visits: number }>;
  referrers: Array<{ source: string; visits: number }>;
  metricStatus: Record<'visits' | 'pageViews' | 'countries' | 'referrers', AnalyticsMetricStatus>;
}

export interface AnalyticsReport {
  id: string;
  period: ReportPeriod;
  aggregate: AnalyticsAggregate;
  generatedAt: string;
  summary: string;
  /** Change from the immediately preceding equivalent report, when stored. */
  delta?: { visits: number; pageViews: number };
}
