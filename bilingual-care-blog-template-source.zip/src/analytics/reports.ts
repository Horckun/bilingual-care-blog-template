import type { AnalyticsProvider } from './provider.ts';
import type { AnalyticsReport, ReportPeriod } from './types.ts';
import type { ReportRepository } from './repository.ts';

export function reportId(period: ReportPeriod): string { return `report-${period.type}-${period.start}-${period.end}-v1`; }

export function buildSummary(report: Pick<AnalyticsReport, 'period' | 'aggregate'>): string {
  return `${report.period.type} report: ${report.aggregate.visits} visits and ${report.aggregate.pageViews} page views.`;
}

export async function generateReport(period: ReportPeriod, provider: AnalyticsProvider, repository: ReportRepository, cron: string, clock = () => new Date()): Promise<AnalyticsReport> {
  const existing = await repository.findByPeriod(period);
  const occurredAt = clock().toISOString();
  if (existing) { await repository.recordRun({ period, status: 'reused', occurredAt, cron }); return existing; }
  try {
    const aggregate = await provider.query(period);
    const previous = await repository.findPrevious(period);
    const delta = previous ? { visits: aggregate.visits - previous.aggregate.visits, pageViews: aggregate.pageViews - previous.aggregate.pageViews } : undefined;
    const report: AnalyticsReport = { id: reportId(period), period, aggregate, generatedAt: occurredAt, summary: buildSummary({ period, aggregate }), ...(delta ? { delta } : {}) };
    const saved = await repository.save(report);
    const status = saved.created ? 'generated' : 'reused';
    await repository.recordRun({ period, status, occurredAt, cron });
    return saved.report;
  } catch {
    await repository.recordRun({ period, status: 'failed', occurredAt, cron });
    throw new Error('Analytics provider query failed.');
  }
}
