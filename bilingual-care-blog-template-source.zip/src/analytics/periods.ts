import type { ReportPeriod } from './types.ts';

const DAY_MS = 86_400_000;

function utcDateOnly(date: Date): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}

function formatDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function shiftDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * DAY_MS);
}

export function getPreviousWeeklyPeriod(now: Date): ReportPeriod {
  const today = utcDateOnly(now);
  const mondayOffset = (today.getUTCDay() + 6) % 7;
  const currentMonday = shiftDays(today, -mondayOffset);
  const start = shiftDays(currentMonday, -7);
  return { type: 'weekly', start: formatDate(start), end: formatDate(shiftDays(currentMonday, -1)) };
}

export function getPreviousMonthlyPeriod(now: Date): ReportPeriod {
  const firstThisMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const lastPreviousMonth = new Date(firstThisMonth.getTime() - DAY_MS);
  const firstPreviousMonth = new Date(Date.UTC(lastPreviousMonth.getUTCFullYear(), lastPreviousMonth.getUTCMonth(), 1));
  return { type: 'monthly', start: formatDate(firstPreviousMonth), end: formatDate(lastPreviousMonth) };
}
