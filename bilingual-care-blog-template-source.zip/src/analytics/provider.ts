import { demoAnalyticsAggregate } from './fixtures.ts';
import type { AnalyticsAggregate, AnalyticsMetricStatus, ReportPeriod } from './types.ts';

export interface AnalyticsProvider {
  query(period: ReportPeriod): Promise<AnalyticsAggregate>;
}

export interface ServerAnalyticsEnvironment {
  /** Server-only secret. Never prefix this variable with PUBLIC_. */
  CLOUDFLARE_ANALYTICS_API_TOKEN: string;
  /** Server-only account identifier. */
  CLOUDFLARE_ACCOUNT_ID: string;
  /** Injectable server-only transport for the Worker runtime and tests. */
  fetch?: typeof fetch;
}

type ProviderMetric = { value: number | null; status: AnalyticsMetricStatus };
type ProviderAggregateInput = {
  visits: ProviderMetric;
  pageViews: ProviderMetric;
  countries: AnalyticsAggregate['countries'];
  referrers: AnalyticsAggregate['referrers'];
};

/** Maps provider values to safe aggregates and keeps uncertainty visible. */
export function normalizeProviderAggregate(input: ProviderAggregateInput): AnalyticsAggregate {
  return {
    visits: input.visits.value ?? 0,
    pageViews: input.pageViews.value ?? 0,
    countries: input.countries,
    referrers: input.referrers,
    metricStatus: {
      visits: input.visits.status,
      pageViews: input.pageViews.status,
      countries: 'available',
      referrers: 'available',
    },
  };
}

export function createFixtureAnalyticsProvider(): AnalyticsProvider {
  return { async query() { return demoAnalyticsAggregate; } };
}

/**
 * Creates a server-side Cloudflare GraphQL adapter. This module must only be
 * imported by a Worker or server route: it deliberately requires server-only
 * environment values and never serializes them into page data.
 */
type GraphQlGroup = { sum?: { visits?: number; pageViews?: number }; count?: number };
type GraphQlResponse = { data?: { viewer?: { accounts?: Array<{ httpRequestsAdaptiveGroups?: GraphQlGroup[] }> } }; errors?: Array<{ message?: string }> };

function numberOrNull(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function graphQlDocument() {
  return `query AnalyticsAggregate($accountTag: String!, $start: String!, $end: String!) {
    viewer { accounts(filter: { accountTag: $accountTag }) {
      httpRequestsAdaptiveGroups(limit: 1, filter: { datetime_geq: $start, datetime_leq: $end }) {
        sum { visits pageViews }
      }
    }}
  }`;
}

export function createCloudflareAnalyticsProvider(env: ServerAnalyticsEnvironment): AnalyticsProvider {
  if (!env.CLOUDFLARE_ANALYTICS_API_TOKEN || !env.CLOUDFLARE_ACCOUNT_ID) {
    throw new Error('Cloudflare analytics provider is not configured.');
  }

  return {
    async query(period) {
      const transport = env.fetch ?? globalThis.fetch;
      const response = await transport('https://api.cloudflare.com/client/v4/graphql', {
        method: 'POST',
        headers: {
          authorization: `Bearer ${env.CLOUDFLARE_ANALYTICS_API_TOKEN}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          query: graphQlDocument(),
          variables: { accountTag: env.CLOUDFLARE_ACCOUNT_ID, start: `${period.start}T00:00:00Z`, end: `${period.end}T23:59:59Z` },
        }),
      });
      if (!response.ok) throw new Error(`Cloudflare analytics request failed (${response.status}).`);
      const payload = await response.json() as GraphQlResponse;
      if (payload.errors?.length) throw new Error(`Cloudflare analytics query failed: ${payload.errors[0]?.message ?? 'unknown error'}`);
      const group = payload.data?.viewer?.accounts?.[0]?.httpRequestsAdaptiveGroups?.[0];
      const visits = numberOrNull(group?.sum?.visits ?? group?.count);
      const pageViews = numberOrNull(group?.sum?.pageViews);
      return normalizeProviderAggregate({
        visits: { value: visits, status: visits === null ? 'unavailable' : 'available' },
        pageViews: { value: pageViews, status: pageViews === null ? 'unavailable' : 'available' },
        countries: [],
        referrers: [],
      });
    },
  };
}
