import type { AnalyticsAggregate } from './types.ts';

/** Fixed local fixture data; it is deliberately aggregate-only and not visitor data. */
export const demoAnalyticsAggregate: AnalyticsAggregate = {
  visits: 128,
  pageViews: 246,
  countries: [
    { country: 'France', visits: 76 },
    { country: 'Spain', visits: 34 },
    { country: 'Other', visits: 18 },
  ],
  referrers: [
    { source: 'Direct', visits: 72 },
    { source: 'Search', visits: 41 },
    { source: 'Referral', visits: 15 },
  ],
  metricStatus: { visits: 'available', pageViews: 'available', countries: 'available', referrers: 'available' },
};
