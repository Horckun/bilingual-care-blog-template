import type { AnalyticsReport, ReportPeriod } from './types.ts';

export type ReportRunStatus = 'generated' | 'reused' | 'failed';
export interface ReportRun { period: ReportPeriod; status: ReportRunStatus; occurredAt: string; cron: string; }

export interface ReportRepository {
  findByPeriod(period: ReportPeriod): Promise<AnalyticsReport | undefined>;
  findPrevious(period: ReportPeriod): Promise<AnalyticsReport | undefined>;
  save(report: AnalyticsReport): Promise<{ report: AnalyticsReport; created: boolean }>;
  recordRun(run: ReportRun): Promise<void>;
}

export interface D1DatabaseLike {
  prepare(query: string): { bind(...values: unknown[]): { first<T>(): Promise<T | null>; run(): Promise<unknown> } };
}

type StoredReport = { id: string; type: ReportPeriod['type']; start_date: string; end_date: string; aggregate_json: string; generated_at: string; summary: string };

export class D1ReportRepository implements ReportRepository {
  private readonly database: D1DatabaseLike;
  constructor(database: D1DatabaseLike) { this.database = database; }
  async findByPeriod(period: ReportPeriod): Promise<AnalyticsReport | undefined> {
    const row = await this.database.prepare('SELECT id, type, start_date, end_date, aggregate_json, generated_at, summary FROM analytics_reports WHERE type = ? AND start_date = ? AND end_date = ? AND schema_version = 1').bind(period.type, period.start, period.end).first<StoredReport>();
    return row ? { id: row.id, period: { type: row.type, start: row.start_date, end: row.end_date }, aggregate: JSON.parse(row.aggregate_json), generatedAt: row.generated_at, summary: row.summary } : undefined;
  }
  async save(report: AnalyticsReport): Promise<{ report: AnalyticsReport; created: boolean }> {
    const result = await this.database.prepare('INSERT INTO analytics_reports (id, type, start_date, end_date, schema_version, aggregate_json, generated_at, summary) VALUES (?, ?, ?, ?, 1, ?, ?, ?) ON CONFLICT(type, start_date, end_date, schema_version) DO NOTHING').bind(report.id, report.period.type, report.period.start, report.period.end, JSON.stringify(report.aggregate), report.generatedAt, report.summary).run() as { meta?: { changes?: number } };
    const stored = (await this.findByPeriod(report.period)) ?? report;
    return { report: stored, created: result.meta?.changes === 1 };
  }
  async findPrevious(period: ReportPeriod): Promise<AnalyticsReport | undefined> {
    const row = await this.database.prepare('SELECT id, type, start_date, end_date, aggregate_json, generated_at, summary FROM analytics_reports WHERE type = ? AND end_date < ? AND schema_version = 1 ORDER BY end_date DESC LIMIT 1').bind(period.type, period.start).first<StoredReport>();
    return row ? { id: row.id, period: { type: row.type, start: row.start_date, end: row.end_date }, aggregate: JSON.parse(row.aggregate_json), generatedAt: row.generated_at, summary: row.summary } : undefined;
  }
  async recordRun(run: ReportRun): Promise<void> {
    await this.database.prepare('INSERT INTO analytics_job_runs (period_type, start_date, end_date, cron, status, occurred_at) VALUES (?, ?, ?, ?, ?, ?)').bind(run.period.type, run.period.start, run.period.end, run.cron, run.status, run.occurredAt).run();
  }
}
