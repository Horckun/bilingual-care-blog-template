export const escapeXml = (value: string) => value.replace(/[<>&"']/g, (character) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[character] ?? character);

export function buildRssXml(input: { title: string; link: string; description: string; items: Array<{ title: string; link: string; description: string; publishedAt: Date }> }) {
  const items = input.items.map((item) => `<item><title>${escapeXml(item.title)}</title><link>${escapeXml(item.link)}</link><description>${escapeXml(item.description)}</description><pubDate>${item.publishedAt.toUTCString()}</pubDate></item>`).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>${escapeXml(input.title)}</title><link>${escapeXml(input.link)}</link><description>${escapeXml(input.description)}</description>${items}</channel></rss>`;
}

export function buildSitemapXml(urls: string[]) {
  return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map((url) => `<url><loc>${escapeXml(url)}</loc></url>`).join('')}</urlset>`;
}
