import { articleSchema, type ArticleData } from '../config/article-schema.ts';
import { getLocalePath, type Locale } from '../config/locales.ts';

export type { ArticleData } from '../config/article-schema.ts';

export interface ArticleSource {
  file: string;
  data: unknown;
  links: readonly string[];
}

export function createArticleLookup<Entry extends { data: ArticleData }>(entries: readonly Entry[]) {
  const published = entries.filter(({ data }) => !data.draft);

  return {
    getArticleByLocaleSlug(locale: Locale, slug: string) {
      return published.find(({ data }) => data.locale === locale && data.slug === slug);
    },
    getTranslation(article: ArticleData, targetLocale: Locale) {
      return published.find(({ data }) => (
        data.locale === targetLocale && data.translationId === article.translationId
      ));
    },
  };
}

async function getArticleLookup() {
  const { getCollection } = await import('astro:content');
  return createArticleLookup(await getCollection('articles'));
}

export async function getArticleByLocaleSlug(locale: Locale, slug: string) {
  return (await getArticleLookup()).getArticleByLocaleSlug(locale, slug);
}

export async function getTranslation(article: ArticleData, targetLocale: Locale) {
  return (await getArticleLookup()).getTranslation(article, targetLocale);
}

function getArticleLinkPath(href: string, articlePath: string): string | null | undefined {
  const target = href.trim();
  if (!target || /^(?:[a-z][a-z\d+.-]*:|\/\/|[\\#?])/i.test(target)) return;

  const url = URL.parse(target, `http://localhost${articlePath}`);
  if (!url) return null;
  if (url.origin !== 'http://localhost' || !/^\/(?:es\/)?blog\/[^/]+\/?$/.test(url.pathname)) return;

  return `${url.pathname.replace(/\/$/, '')}/`;
}

export function validateContent(sources: readonly ArticleSource[]) {
  const errors: string[] = [];
  const identifiers = new Map<string, string>();
  const translations = new Map<string, string>();
  const routes = new Map<string, string>();
  const publicRoutes = new Set<string>();
  const validSources: { source: ArticleSource; route: string }[] = [];

  function registerUnique(seen: Map<string, string>, label: string, key: string, file: string) {
    const previous = seen.get(key);
    if (previous === undefined) {
      seen.set(key, file);
    } else {
      errors.push(`${file}: duplicate ${label} ${key} (also in ${previous}).`);
    }
  }

  for (const source of sources) {
    const result = articleSchema.safeParse(source.data);
    if (!result.success) {
      for (const issue of result.error.issues) {
        errors.push(`${source.file}: ${issue.path.join('.') || 'front matter'}: ${issue.message}`);
      }
      continue;
    }

    const { id, locale, translationId, slug, draft } = result.data;
    if (!source.file.startsWith(`${locale}/`)) {
      errors.push(`${source.file}: place this article in the ${locale}/ directory.`);
    }

    const route = getLocalePath(locale, 'blog', slug);
    registerUnique(identifiers, 'ID', id, source.file);
    registerUnique(translations, 'locale/translation ID', `${locale}/${translationId}`, source.file);
    registerUnique(routes, 'article route', route, source.file);
    if (!draft) publicRoutes.add(route);
    validSources.push({ source, route });
  }

  for (const { source, route } of validSources) {
    for (const href of source.links) {
      const target = getArticleLinkPath(href, route);
      if (target === null) {
        errors.push(`${source.file}: malformed link ${JSON.stringify(href)}.`);
      } else if (target && !publicRoutes.has(target)) {
        errors.push(`${source.file}: article link ${href} has no published destination.`);
      }
    }
  }

  return { ok: errors.length === 0, errors };
}
