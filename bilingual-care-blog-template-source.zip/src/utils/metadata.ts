import type { DeploymentMode } from '../config/site.ts';

export function getCanonicalUrl(path: string, mode: DeploymentMode, origin = ''): string | null {
  return mode === 'production' && origin ? new URL(path, `${origin}/`).toString() : null;
}

export function buildHreflang(frPath: string, esPath: string, origin: string) {
  return [
    { lang: 'fr', href: new URL(frPath, `${origin}/`).toString() },
    { lang: 'es', href: new URL(esPath, `${origin}/`).toString() },
  ];
}

export function buildRobots(mode: DeploymentMode) {
  return mode === 'production' ? 'index,follow' : 'noindex,nofollow';
}

export function buildWebsiteJsonLd(name: string, canonical: string | null) {
  return canonical ? { '@context': 'https://schema.org', '@type': 'WebSite', name, url: canonical } : null;
}

type ArticleDate = Date | string;

function toIsoDate(value: ArticleDate) {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

export function buildArticleJsonLd(article: { title: string; description: string; publishedAt: ArticleDate; updatedAt?: ArticleDate }, canonical: string | null) {
  return canonical ? { '@context': 'https://schema.org', '@type': 'Article', headline: article.title, description: article.description, datePublished: toIsoDate(article.publishedAt), ...(article.updatedAt ? { dateModified: toIsoDate(article.updatedAt) } : {}), mainEntityOfPage: canonical } : null;
}
