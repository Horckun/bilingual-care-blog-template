import { createProcessor } from '@mdx-js/mdx';
import { parse } from 'yaml';
import type { ArticleSource } from './content.ts';

interface EstreeStatement {
  type: string;
  expression?: { type: string; value?: unknown };
}

type MarkdownAttributeValue = string | null | {
  type: string;
  data?: { estree?: { body: readonly EstreeStatement[] } | null };
};

interface MarkdownNode {
  type: string;
  children?: readonly MarkdownNode[];
  url?: string;
  identifier?: string;
  name?: string | null;
  attributes?: readonly { type: string; name?: unknown; value?: MarkdownAttributeValue }[];
}

const mdx = createProcessor({ format: 'mdx' });

function readStaticHref(value: MarkdownAttributeValue | undefined): string | undefined {
  if (typeof value === 'string') return value;
  if (value?.type !== 'mdxJsxAttributeValueExpression') return;

  const body = value.data?.estree?.body;
  if (body?.length !== 1 || body[0].type !== 'ExpressionStatement') return;

  const expression = body[0].expression;
  if (expression?.type === 'Literal' && typeof expression.value === 'string') return expression.value;
}

export function readArticleSource(file: string, contents: string): ArticleSource {
  const frontMatter = /^\uFEFF?---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/.exec(contents);
  if (!frontMatter) throw new Error('Missing YAML front matter.');

  const data: unknown = parse(frontMatter[1]);
  const tree = mdx.parse(contents.slice(frontMatter[0].length));
  const definitions = new Map<string, string>();
  const targets: (string | { reference: string })[] = [];

  function collectLinks(node: MarkdownNode) {
    if (node.type === 'definition' && node.identifier && node.url && !definitions.has(node.identifier)) {
      definitions.set(node.identifier, node.url);
    }
    if (node.type === 'link' && node.url) targets.push(node.url);
    if (node.type === 'linkReference' && node.identifier) targets.push({ reference: node.identifier });
    if ((node.type === 'mdxJsxTextElement' || node.type === 'mdxJsxFlowElement') && node.name === 'a') {
      const href = node.attributes?.find((attribute) => attribute.type === 'mdxJsxAttribute' && attribute.name === 'href');
      const target = readStaticHref(href?.value);
      if (target !== undefined) targets.push(target);
    }

    node.children?.forEach(collectLinks);
  }

  collectLinks(tree);
  const links = targets.flatMap((target) => {
    if (typeof target === 'string') return [target];
    const url = definitions.get(target.reference);
    return url ? [url] : [];
  });

  return { file, data, links };
}
