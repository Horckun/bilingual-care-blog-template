import { z } from 'astro/zod';
import { locales } from './locales.ts';

const nonBlankText = z.string().trim().min(1);
const slug = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);
const calendarDate = z.preprocess(
  (value) => value instanceof Date && Number.isFinite(value.getTime())
    ? value.toISOString().split('T')[0]
    : value,
  z.string().date(),
);

export const articleSchema = z.object({
  id: nonBlankText,
  locale: z.enum(locales),
  translationId: nonBlankText,
  slug,
  title: nonBlankText,
  description: nonBlankText,
  publishedAt: calendarDate,
  updatedAt: calendarDate,
  cover: z.string().regex(/^\/(?!\/)[^\s?#\\]+$/).nullable(),
  alt: nonBlankText.nullable(),
  category: slug,
  tags: z.array(slug),
  draft: z.boolean(),
}).strict().refine(({ cover, alt }) => (cover === null) === (alt === null), {
  path: ['alt'],
  message: 'Provide alt text when an article has a cover, or use null for both fields.',
});

export type ArticleData = z.infer<typeof articleSchema>;
