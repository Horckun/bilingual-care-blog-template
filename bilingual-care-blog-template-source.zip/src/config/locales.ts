export const locales = ['fr', 'es'] as const;
export type Locale = (typeof locales)[number];

const sections = {
  blog: { fr: 'blog', es: 'blog' },
  profession: { fr: 'le-metier', es: 'oficio' },
  questions: { fr: 'questions', es: 'preguntas' },
  about: { fr: 'a-propos', es: 'acerca-de' },
  contact: { fr: 'contact', es: 'contacto' },
  category: { fr: 'categorie', es: 'categoria' },
  tags: { fr: 'tags', es: 'etiquetas' },
} as const;

export type LocaleSection = keyof typeof sections;

export function getLocalePath(locale: Locale, section?: LocaleSection, slug?: string): string {
  const segments = [locale === 'es' ? locale : '', section ? sections[section][locale] : '', slug];
  return `/${segments.filter(Boolean).map((segment) => `${segment}/`).join('')}`;
}
