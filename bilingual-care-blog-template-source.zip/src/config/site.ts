export type DeploymentMode = 'preview' | 'production';

const rawMode = import.meta.env.PUBLIC_DEPLOYMENT_MODE;
export const deploymentMode: DeploymentMode = rawMode === 'production' ? 'production' : 'preview';
export const siteUrl = import.meta.env.PUBLIC_SITE_URL?.replace(/\/$/, '') ?? '';
export const siteName = 'Bilingual Care Blog';
